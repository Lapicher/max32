
//add options for setting clock speed rather then single setting
void clock_init();

void setClockFrequency();

void selectMasterClock(uint8_t clockSelection);
/*
PMC_MCKR_CSS_MAIN_CLK
PMC_MCKR_CSS_SLOW_CLK
PMC_MCKR_CSS_PLLA_CLK
PMC_MCKR_CSS_PLLB_CLK
*/

void setMasterClockPreScaler(uint8_t preScaler);
/*
PMC_MCKR_PRES_CLK_1
PMC_MCKR_PRES_CLK_2
PMC_MCKR_PRES_CLK_4
PMC_MCKR_PRES_CLK_8
PMC_MCKR_PRES_CLK_16
PMC_MCKR_PRES_CLK_32
PMC_MCKR_PRES_CLK_64
PMC_MCKR_PRES_CLK_3
*/