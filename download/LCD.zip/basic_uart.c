
#include "sam.h"
#include "basic_uart.h"

void UART_Init(){	
	NVIC_EnableIRQ(UART0_IRQn);
	
	//configure PIO controller A  - disable means enable peripheral on pins		
	REG_PIOA_PDR |= PIO_PDR_P9; //disable PIOA control of PA9 and enable peripheral on pin
	REG_PIOA_PDR |= PIO_PDR_P10; //disable PIOA control of PA9 and enable peripheral on pin
	REG_PIOA_ABCDSR &=  ~(PIO_ABCDSR_P9);
	REG_PIOA_ABCDSR &=  ~(PIO_ABCDSR_P10);	
		
	//configure PMC UART Clock	
	REG_PMC_PCER0 |= PMC_PCER0_PID8; //enable UART0 clock
		
	//configure buad rate
	REG_UART0_BRGR |= 130; 
	//fcpu/16xBR 20,000,000/(16x9600)=130
	//fcpu/16xBR 20,000,000/(16x4800)=260
	//fcpu/16xBR 1,000,000/(16x9600)=7
		
	//parity
	REG_UART0_MR |= UART_MR_PAR_NO;
		
	//mode
	//normal mode default
	
	//enable transmit/receive
	REG_UART0_CR |= UART_CR_TXEN;
	REG_UART0_CR |= UART_CR_RXEN;
	
	//enable interrupt on receive
	REG_UART0_IER |= UART_IER_RXRDY;
	
	
}

void transmitByte(uint8_t data){
	//wait for ready
	while (!(REG_UART0_SR&UART_SR_TXRDY));
	while (!(REG_UART0_SR&UART_SR_TXEMPTY));
	REG_UART0_THR |= data;	
}

void printString(const char myString[]) {
	uint8_t i = 0;
	while (myString[i]) {
		transmitByte(myString[i]);
		i++;
	}
}

void printByte(uint8_t byte) {
	transmitByte('0' + (byte / 100));                        /* Hundreds */
	transmitByte('0' + ((byte / 10) % 10));                      /* Tens */
	transmitByte('0' + (byte % 10));                             /* Ones */
}

void printWord(uint16_t word) {
	
	
	transmitByte('0' + (word / 10000));                 /* Ten-thousands */
	transmitByte('0' + ((word / 1000) % 10));               /* Thousands */
	transmitByte('0' + ((word / 100) % 10));                 /* Hundreds */
	transmitByte('0' + ((word / 10) % 10));                      /* Tens */
	transmitByte('0' + (word % 10));                             /* Ones */
}



void printBinaryByte(uint8_t byte) {
	/* Prints out a byte as a series of 1's and 0's */
	uint8_t bit;
	for (bit = 7; bit < 255; bit--) {
		//if (bit_is_set(byte, bit))
		if (((byte & 1<<bit) >= 1)){
		transmitByte('1');
		}
		else{
		transmitByte('0');
		}
	}
}

char nibbleToHexCharacter(uint8_t nibble) {
	/* Converts 4 bits into hexadecimal */
	if (nibble < 10) {
		return ('0' + nibble);
	}
	else {
		return ('A' + nibble - 10);
	}
}

void printHexByte(uint8_t byte) {
	/* Prints a byte as its hexadecimal equivalent */
	uint8_t nibble;
	nibble = (byte & 0b11110000) >> 4;
	transmitByte(nibbleToHexCharacter(nibble));
	nibble = byte & 0b00001111;
	transmitByte(nibbleToHexCharacter(nibble));
}

void UART0_Handler( void) {
	// when we receive a byte, transmit that byte back
	uint32_t status = REG_UART0_SR;
	if ((status & UART_SR_RXRDY)){
		//read receive holding register
		uint8_t readByte = REG_UART0_RHR;
		//transmit that byte back
		transmitByte(readByte);
	}
}
