
void UART_Init();

void transmitByte(uint8_t data);

void printString(const char myString[]);

void printByte(uint8_t byte);

void printWord(uint16_t word);


void printBinaryByte(uint8_t byte);

char nibbleToHexCharacter(uint8_t nibble);

void printHexByte(uint8_t byte);

void UART0_Handler( void);