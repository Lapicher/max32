#include "sam.h"
//#include "basic_uart.h"

//pin and mode defines for all slaves
#define SPI_NHDLCD_SS	31 //PIO_CODR_P31 or PIO_SODR_P31 //pin slave is on
#define SPI_NHDLCD_MODE	3 //spi mode

void SPI_setMode(uint8_t mode);

void SPI_selectPeripheral(uint8_t peripheral);
/*
built in pins for spi slaves, but can use any gpio active low using slave select and slavedeselect
*/

void SPI_init();

void SPI_slaveSelect(uint8_t slave);
/*
slave is pin
*/

void SPI_slaveDeselect(uint8_t slave);
/*
wait for transfer to be comlete
signal last transfer
slave pin goes high to deselect
*/

uint8_t SPI_byteExchange(uint8_t data);
/*
send a byte, receive a byte
*/

