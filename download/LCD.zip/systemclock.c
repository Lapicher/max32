#include "sam.h"
#include "systemclock.h"

void clock_init(){
	REG_CKGR_MOR |= CKGR_MOR_KEY_PASSWD | CKGR_MOR_MOSCXTEN; //enable external crystal
	while (!(REG_PMC_SR & PMC_SR_MOSCXTS)); //wait for crystal to become ready
	REG_CKGR_MOR |= CKGR_MOR_KEY_PASSWD | CKGR_MOR_MOSCSEL; //select crystal
	REG_PMC_MCKR |= PMC_MCKR_CSS_MAIN_CLK; //master clock source selection - choose main clock
	while (!(REG_PMC_SR & PMC_SR_MCKRDY)); //wait until main clock ready
	REG_PMC_MCKR |= PMC_MCKR_PRES_CLK_1; //select processer prescaler (0 - no divisor)
	while (!(REG_PMC_SR & PMC_SR_MCKRDY)); //wait until main clock ready
}

void selectMasterClock(uint8_t clockSelection){
	//check clock selection is valid and then change
	/*
	PMC_MCKR_CSS_MAIN_CLK = 0
	PMC_MCKR_CSS_SLOW_CLK = 1
	PMC_MCKR_CSS_PLLA_CLK = 2
	PMC_MCKR_CSS_PLLB_CLK = 3
	*/
	if (clockSelection>=0 && clockSelection <=3){
		REG_PMC_MCKR = (REG_PMC_MCKR & ~(PMC_MCKR_CSS_Msk<<PMC_MCKR_CSS_Pos)) | PMC_MCKR_CSS(clockSelection);
	}
	else{
		//clockSelection out of range
	}
	
}

void setMasterClockPreScaler(uint8_t preScaler){
	/*
	PMC_MCKR_PRES_CLK_1
	PMC_MCKR_PRES_CLK_2
	PMC_MCKR_PRES_CLK_4
	PMC_MCKR_PRES_CLK_8
	PMC_MCKR_PRES_CLK_16
	PMC_MCKR_PRES_CLK_32
	PMC_MCKR_PRES_CLK_64
	PMC_MCKR_PRES_CLK_3
	*/
	//check preScaler in range
	if (preScaler>=0 && preScaler<=7){
		REG_PMC_MCKR = (REG_PMC_MCKR & ~(PMC_MCKR_PRES_Msk<<PMC_MCKR_PRES_Pos)) | PMC_MCKR_PRES(preScaler);
	}
	else{
		//preScaler out of range
	}
}