/*
 * LCD Module NHD-C12832A1Z.c
 *
 * Created: 1/16/2018 5:40:09 AM
 * Author : robert
 */ 


#include "sam.h"
#include "NHD-C12832A1Z.h"
#include "SPI.h"
#include "systemclock.h"
#include "basic_uart.h"

uint8_t counter = 0; // counter for TC0
uint8_t manPosition = 0;
uint8_t manFrame = 0;

void timerInit(){
	//Setup for TC0 - ID 23, TIOA0 - PA0 peripheral B
	
	//enable interrupts in NVIC for TC0
	NVIC_EnableIRQ(TC0_IRQn);
	
	//PMC setup
	REG_PMC_PCER0 |= PMC_PCER0_PID23; 	//enable peripheral clock	for timer counter channel0
	
	//Interrupt Setup
	REG_TC0_CMR0 |= TC_CMR_TCCLKS_TIMER_CLOCK1; //mainclock div 2
	REG_TC0_IER0 |= TC_IER_COVFS; //enable couter overflow interrupt
	REG_TC0_CCR0 |= TC_CCR_CLKEN; //enable tc clock
	
	//PIO setup (not neccessary) because we won't use the pins
	
}

int main(void)
{
    /* Initialize the SAM system */
    SystemInit();
	clock_init();	
	UART_Init();
	printString("uart init");
	//setup LCD pins (output)
	//give control to GPIO, not peripheral
	REG_PIOA_PER |= LCDDATACMDPIN | LCDSSPIN | LCDRESETPIN;
	//set as output
	REG_PIOA_OER |= LCDDATACMDPIN | LCDSSPIN | LCDRESETPIN;
	//set default state
	REG_PIOA_SODR |= PIO_SODR_P20;
	REG_PIOA_CODR |= PIO_CODR_P19 | PIO_CODR_P21;
	
	SPI_init();		
	NHD_init();	
	timerInit();
	//start our TC0
	REG_TC0_CCR0 |= TC_CCR_SWTRG;
	
    /* Replace with your application code */
    while (1) 
    {
		
		
    }
}


void TC0_Handler(void){
	
	uint32_t status = REG_TC0_SR0; //read status register - this clears interrupt flags
	if ((status & TC_SR_COVFS)>=1){
		//increment counter
		counter+=1;
		//printByte(counter);
	}
	
	if (counter>20){
		//reset counter
		counter=0;
		//Run Code
			//NHD_testPattern();
			NHD_clearScreen();
			NHD_displayMan(manPosition,manFrame);	
			manFrame++;
			manPosition+=5;
			if (manFrame >= 3){
				manFrame = 0;
			}
			if (manPosition >= 128){
				manPosition = 0;
			}
	}
	
}
