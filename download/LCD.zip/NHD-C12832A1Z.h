#include "sam.h"
/*
SPI 10Mhz

explain RAM strucure, write sequence

Pin		Description
VCC		3V3
GND		Ground
DATA	SPI DATA
CLK		SPI CLOCK
D/C		Data or Command: 0: cmd, 1: data
SS		SLAVE SELECT: Active low
RES		RESET: Active low

*/
//ATSAM4S connection pins
#define LCDDATACMDPIN	PIO_CODR_P19
#define LCDSSPIN		PIO_CODR_P20
#define LCDRESETPIN		PIO_CODR_P21

//Define//
#define NHDCMD_DISPLAY_ON	0b10101111
#define NHDCMD_DISPLAY_OFF	0b10101110
#define NHDCMD_DISPLAY_START_LINE	0b01 << 6 // OR with line number, ie line 3 0b01000011
#define NHDCMD_PAGE_ADDRESS_SET		0b1011 << 4 // OR with page number
#define NHDCMD_COL_ADDRESS_SET		//????
/*
send two bytes
0001 MSNIBBLE
0000 LSNIBBLE
*/

#define NHDCMD_STATUS_READ	0b00000000 
/*
//send dummy, but read returned result
D7	BUSY	-	0: Not Busy, 1: Busy
D6	ADC		-	0: Reverse, 1: Normal
D5	ON/OFF	-	0: Dislay off, 1: Display on
D4	RESET	-	0: Operating State, 1: Reset in progress
*/

#define NHDCMD_ADC_ON	0b10100001
#define NHDCMD_ADC_OFF	0b10100000
/*
reverse column direction
*/


#define NHDCMD_DISPLAY_REVERSE_ON	0b10100111
#define NHDCMD_DISPLAY_REVERSE_OFF	0b10100110
/*
Invert colour
*/

#define NHDCMD_DISPLAY_ALL_POINTS_ON	0b10100101
#define NHDCMD_DISPLAY_ALL_POINTS_OFF	0b10100100
/*
Turns on all bits
*/

#define NHDCMD_LCD_BIAS_1_9		0b10100010
#define NHDCMD_LCD_BIAS_1_7		0b10100011
/*
Sets LCD bias
*/

#define NHDCMD_READ_MODIFY_WRITE	0b11100000
/*
used with END command unsure what it does
*/

#define NHDCMD_END	0b11101110
/*
clears NHDCMD_READ_MODIFY_WRITE
*/

#define NHDCMD_RESET	0b11100010
/*
reset LCD
*/

#define NHDCMD_COMMON_OUTPUT_MODE_SELECT_NORMAL		0b11000000
#define NHDCMD_COMMON_OUTPUT_MODE_SELECT_REVERSE	0b11001000
/*
COM output scan direction
*/

#define NHDCMD_POWER_CONTROL_SET	0b00101000 // OR with the following optionts
#define NHDCMD_BOOSTER_ON	0b100
#define NHDCMD_BOOSTER_OFF	0b000
#define NHDCMD_VOLTAGE_REGULATOR_ON	0b10
#define NHDCMD_VOLTAGE_REGULATOR_OFF	0b00
#define NHDCMD_VOLTAGE_FOLLOWER_ON	0b1
#define NHDCMD_VOLTAGE_FOLLOWER_OFF	0b0
/*
redo this
ie:
powerControlByte = NHDCMD_POWER_CONTROL_SET | NHDCMD_BOOSTER | NHCMD_VOLTAGE_REGULATOR_ON | NHCMD_VOLTAGE_FOLLOWER_OFF
*/

#define NHDCMD_VOLTAGE_REGULATOR_RESISTOR_RATIO_SET_MIN	0b00100000 //small
#define NHDCMD_VOLTAGE_REGULATOR_RESISTOR_RATIO_SET_1	0b00100001
#define NHDCMD_VOLTAGE_REGULATOR_RESISTOR_RATIO_SET_2	0b00100010
#define NHDCMD_VOLTAGE_REGULATOR_RESISTOR_RATIO_SET_3	0b00100011
#define NHDCMD_VOLTAGE_REGULATOR_RESISTOR_RATIO_SET_4	0b00100100
#define NHDCMD_VOLTAGE_REGULATOR_RESISTOR_RATIO_SET_5	0b00100101
#define NHDCMD_VOLTAGE_REGULATOR_RESISTOR_RATIO_SET_6	0b00100110
#define NHDCMD_VOLTAGE_REGULATOR_RESISTOR_RATIO_SET_MAX	0b00100111 //large

#define NHDCMD_ELECTRONIC_VOLUME	0b10000001
/*
not sure what this does
send command
send databyte
*/

#define NHD_PAGEADDRESS_0	0b10110000	
#define NHD_PAGEADDRESS_1	0b10110001	
#define NHD_PAGEADDRESS_2	0b10110010	
#define NHD_PAGEADDRESS_3	0b10110011	
#define NHD_PAGEADDRESS_4	0b10110100	
#define NHD_PAGEADDRESS_5	0b10110101
#define NHD_PAGEADDRESS_6	0b10110110	
#define NHD_PAGEADDRESS_7	0b10110111	
#define NHD_PAGEADDRESS_8	0b10111000	

#define NHDCMD_SLEEP_ON		0b10101100
#define NHDCMD_SLEEP_OFF	0b10101101
#define NHDCMD_INIT			0b00000000
/*
send two bytes one after the other
*/

//functions//
void NHD_init();//options as input

void NHD_slaveselect();
void NHD_slavedeselect();

void NHD_sendCommand(uint8_t command);

void NHD_sendData(uint8_t data);

uint8_t NHD_readData();//page and column address as input

void NHD_setPageAddress (uint8_t page);
void NHD_setColumnAddress (uint8_t column);

void NHD_clearScreen(); //resets all bits

void NHD_testPattern ();
void NHD_displayMan (uint8_t x, uint8_t frame);
