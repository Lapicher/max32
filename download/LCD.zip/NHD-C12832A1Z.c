#include "NHD-C12832A1Z.h"
#include "spi.h"
#include "lcd_images.h"



void NHD_init(){
	REG_PIOA_SODR |= PIO_SODR_P21; // reset pin high to stop reset
	NHD_sendCommand(NHDCMD_LCD_BIAS_1_9);
	NHD_sendCommand(NHDCMD_ADC_OFF);
	NHD_sendCommand(NHDCMD_COMMON_OUTPUT_MODE_SELECT_REVERSE);
	
	NHD_sendCommand(NHDCMD_VOLTAGE_REGULATOR_RESISTOR_RATIO_SET_1);
	NHD_sendCommand(NHDCMD_POWER_CONTROL_SET | NHDCMD_BOOSTER_ON | NHDCMD_VOLTAGE_REGULATOR_ON | NHDCMD_VOLTAGE_FOLLOWER_ON);
	NHD_sendCommand(NHDCMD_ELECTRONIC_VOLUME);
	NHD_sendCommand(0x2f);
	NHD_sendCommand(NHDCMD_DISPLAY_ON);
}

void NHD_slaveselect(){
	REG_PIOA_CODR |= PIO_CODR_P20;
	
}

void NHD_slavedeselect(){
	REG_PIOA_SODR |= LCDSSPIN;
}

void NHD_sendCommand(uint8_t command){
	REG_PIOA_CODR |= PIO_CODR_P20;
	REG_PIOA_CODR |= PIO_CODR_P19;
	SPI_byteExchange(command);
	REG_PIOA_SODR |= PIO_SODR_P20;
}

void NHD_sendData(uint8_t data){
	REG_PIOA_CODR |= PIO_CODR_P20;
	REG_PIOA_SODR |= PIO_SODR_P19;
	SPI_byteExchange(data);
	REG_PIOA_SODR |= PIO_SODR_P20;
}

void NHD_setPageAddress (uint8_t page){
	if (page == 0){
		NHD_sendCommand(NHD_PAGEADDRESS_0);
	}
	else if (page == 1){
		NHD_sendCommand(NHD_PAGEADDRESS_1);
	}
	else if (page == 2){
		NHD_sendCommand(NHD_PAGEADDRESS_2);
	}
	else if (page == 3){
		NHD_sendCommand(NHD_PAGEADDRESS_3);
	}
}

void NHD_setColumnAddress (uint8_t column){
	uint8_t colMSB = 0b00010000 | (column>>4);
	uint8_t colLSB = 0b00000000 | (column & 0b00001111);
	NHD_sendCommand(colMSB);
	NHD_sendCommand(colLSB);
}


void NHD_clearScreen(){
	NHD_sendCommand(0b01000000);
	for (uint8_t i=0; i<4; i++){
		NHD_setPageAddress(i);
		NHD_setColumnAddress (0);
		for (uint8_t j=0; j<128;j++){
			NHD_sendData(0b00000000);
		}
	}
}

void NHD_testPattern (){
	NHD_sendCommand(0b01000000);
	NHD_sendCommand(NHD_PAGEADDRESS_3);
	NHD_setColumnAddress (0);
	for (uint8_t i=0; i<8; i++){
		for (uint8_t x=0; x<8;x++){
			NHD_sendData(0b00000000);
		}
		for (uint8_t x=0; x<8;x++){
			NHD_sendData(0b11111111);
		}
	}
	
	NHD_sendCommand(NHD_PAGEADDRESS_2);
	NHD_setColumnAddress (0);
	for (uint8_t i=0; i<8; i++){
		for (uint8_t x=0; x<8;x++){
			NHD_sendData(0b11111111);
		}
		for (uint8_t x=0; x<8;x++){
			NHD_sendData(0b00000000);
		}
	}
	
	NHD_sendCommand(NHD_PAGEADDRESS_1);
	NHD_setColumnAddress (0);
	for (uint8_t i=0; i<8; i++){
		for (uint8_t x=0; x<8;x++){
			NHD_sendData(0b00000000);
		}
		for (uint8_t x=0; x<8;x++){
			NHD_sendData(0b11111111);
		}
	}
	
	NHD_sendCommand(NHD_PAGEADDRESS_0);
	NHD_setColumnAddress (0);
	for (uint8_t i=0; i<8; i++){
		for (uint8_t x=0; x<8;x++){
			NHD_sendData(0b11111111);
		}
		for (uint8_t x=0; x<8;x++){
			NHD_sendData(0b00000000);
		}
	}
	
}

void NHD_displayMan (uint8_t x, uint8_t frame){
	NHD_sendCommand(0b01000000);
	for (uint8_t i=0; i<4; i++){
		NHD_setPageAddress(i);
		NHD_setColumnAddress (x);
		for (uint8_t j=0; j<32;j++){
			NHD_sendData(runningMan[frame][j + (i*32)]);
		}
	}
}